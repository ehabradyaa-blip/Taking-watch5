package com.example.talkingclock

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val pad = (24 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(pad, pad, pad, pad)
        val tv = TextView(this)
        tv.textSize = 20f
        tv.text = "ناطق الساعة\n\nاضغط «تسجيل الأمر»، وبعد كل اهتزازة قصيرة قل: الساعة كام. " +
            "كرر ٥ مرات، وعند الاهتزازة الطويلة يكون الأمر جاهزاً."
        root.addView(tv)
        root.addView(button("تسجيل الأمر") {
            if (hasPerms()) startTimeService(this, "ENROLL") else askPerms()
        })
        root.addView(button("انطق الوقت الآن") {
            if (hasPerms()) startTimeService(this, "SPEAK") else askPerms()
        })
        root.addView(button("إغلاق") { finish() })
        setContentView(root)
        if (hasPerms()) begin() else askPerms()
    }

    private fun button(t: String, f: () -> Unit): Button {
        val b = Button(this)
        b.text = t
        b.textSize = 20f
        b.setOnClickListener { f() }
        return b
    }

    private fun hasPerms(): Boolean =
        checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    private fun askPerms() {
        val need = mutableListOf(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33) need.add(Manifest.permission.POST_NOTIFICATIONS)
        requestPermissions(need.toTypedArray(), 1)
    }

    override fun onRequestPermissionsResult(code: Int, p: Array<out String>, r: IntArray) {
        if (hasPerms()) begin()
    }

    private fun begin() {
        startTimeService(this, "SPEAK")
        val prefs = getSharedPreferences("p", Context.MODE_PRIVATE)
        if (!prefs.getBoolean("asked", false)) {
            prefs.edit().putBoolean("asked", true).apply()
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            if (!pm.isIgnoringBatteryOptimizations(packageName)) {
                try {
                    startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                        Uri.parse("package:$packageName")))
                } catch (e: Exception) { }
            }
        }
    }
}
