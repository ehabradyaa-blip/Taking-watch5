package com.example.talkingclock

import android.content.Context
import android.content.Intent
import android.os.Build

fun startTimeService(ctx: Context, action: String?) {
    val i = Intent(ctx, TimeService::class.java)
    if (action != null) i.action = action
    if (Build.VERSION.SDK_INT >= 26) ctx.startForegroundService(i) else ctx.startService(i)
}
