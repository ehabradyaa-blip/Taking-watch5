package com.example.talkingclock

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaPlayer
import android.media.MediaRecorder
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import android.os.VibrationEffect
import android.os.Vibrator
import java.io.DataInputStream
import java.io.DataOutputStream
import java.io.File
import java.util.Calendar
import kotlin.math.log10
import kotlin.math.sqrt

class TimeService : Service() {
    private var last = 0L
    private var player: MediaPlayer? = null
    private val queue = mutableListOf<Int>()
    private val handler = Handler(Looper.getMainLooper())
    @Volatile private var speaking = false
    @Volatile private var lastEnd = 0L
    @Volatile private var running = true
    @Volatile private var enrolling = false
    @Volatile private var templates: List<Array<FloatArray>> = emptyList()
    @Volatile private var thr = 1.2f
    private val samples = mutableListOf<Array<FloatArray>>()
    private var thread: Thread? = null

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            val now = SystemClock.elapsedRealtime()
            if (last != 0L && now - last < 1800) {
                last = 0L
                speakTime()
            } else {
                last = now
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        val n: Notification = if (Build.VERSION.SDK_INT >= 26) {
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(
                NotificationChannel("clock", "Talking clock", NotificationManager.IMPORTANCE_LOW))
            Notification.Builder(this, "clock")
                .setContentTitle("ناطق الساعة شغال")
                .setSmallIcon(android.R.drawable.ic_lock_idle_alarm).build()
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(this)
                .setContentTitle("ناطق الساعة شغال")
                .setSmallIcon(android.R.drawable.ic_lock_idle_alarm).build()
        }
        if (Build.VERSION.SDK_INT >= 30) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } else {
            startForeground(1, n)
        }
        val f = IntentFilter()
        f.addAction(Intent.ACTION_SCREEN_ON)
        f.addAction(Intent.ACTION_SCREEN_OFF)
        registerReceiver(receiver, f)
        loadTemplates()
        thread = Thread { listenLoop() }.also { it.start() }
    }

    // ---------- storage ----------
    private fun tplFile() = File(filesDir, "tpl.bin")

    private fun loadTemplates() {
        try {
            val f = tplFile()
            if (!f.exists()) return
            DataInputStream(f.inputStream().buffered()).use { d ->
                thr = d.readFloat()
                val cnt = d.readInt()
                val list = mutableListOf<Array<FloatArray>>()
                for (t in 0 until cnt) {
                    val frames = d.readInt()
                    list.add(Array(frames) { FloatArray(Dsp.NC) { d.readFloat() } })
                }
                templates = list
            }
        } catch (e: Exception) { }
    }

    private fun saveTemplates(list: List<Array<FloatArray>>, threshold: Float) {
        try {
            DataOutputStream(tplFile().outputStream().buffered()).use { d ->
                d.writeFloat(threshold)
                d.writeInt(list.size)
                for (t in list) {
                    d.writeInt(t.size)
                    for (fr in t) for (v in fr) d.writeFloat(v)
                }
            }
        } catch (e: Exception) { }
    }

    // ---------- vibration feedback ----------
    private fun vib(p: LongArray) {
        lastEnd = SystemClock.elapsedRealtime() + p.sum() + 600
        try {
            val v = getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
            if (Build.VERSION.SDK_INT >= 26) {
                v.vibrate(VibrationEffect.createWaveform(p, -1))
            } else {
                @Suppress("DEPRECATION") v.vibrate(p, -1)
            }
        } catch (e: Exception) { }
    }

    private val shortBuzz = longArrayOf(0, 200)
    private val rejectBuzz = longArrayOf(0, 120, 120, 120)
    private val doneBuzz = longArrayOf(0, 800)

    // ---------- listening ----------
    private fun energyDb(c: ShortArray): Double {
        var s = 0.0
        for (v in c) s += v.toDouble() * v.toDouble()
        val rms = sqrt(s / c.size)
        return 20.0 * log10(rms / 32768.0 + 1e-9)
    }

    private fun listenLoop() {
        val rate = Dsp.SR
        val minBuf = AudioRecord.getMinBufferSize(rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val rec = try {
            AudioRecord(MediaRecorder.AudioSource.MIC, rate, AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT, maxOf(minBuf, 8192) * 2)
        } catch (e: Exception) {
            return
        }
        if (rec.state != AudioRecord.STATE_INITIALIZED) return
        try {
            rec.startRecording()
        } catch (e: Exception) {
            return
        }
        val chunk = ShortArray(320)
        val pre = java.util.ArrayDeque<ShortArray>()
        val seg = ArrayList<ShortArray>()
        var noise = -60.0
        var inSpeech = false
        var hi = 0
        var lo = 0
        while (running) {
            val n = rec.read(chunk, 0, 320)
            if (n != 320) continue
            val c = chunk.copyOf()
            val e = energyDb(c)
            val now = SystemClock.elapsedRealtime()
            if (speaking || now - lastEnd < 800) {
                inSpeech = false; hi = 0; lo = 0
                seg.clear(); pre.clear()
                continue
            }
            if (!inSpeech) {
                noise += (e - noise) * (if (e < noise) 0.05 else 0.005)
                pre.addLast(c)
                if (pre.size > 10) pre.removeFirst()
                if (e > noise + 12 && e > -50) hi++ else hi = 0
                if (hi >= 3) {
                    inSpeech = true
                    seg.clear()
                    seg.addAll(pre)
                    lo = 0
                }
            } else {
                seg.add(c)
                if (e < noise + 8) lo++ else lo = 0
                if (lo >= 18 || seg.size > 150) {
                    val keep = minOf(seg.size - lo + 3, seg.size)
                    val tooLong = seg.size > 150
                    if (!tooLong && keep in 18..120) {
                        val pcm = ShortArray(keep * 320)
                        for (i in 0 until keep) System.arraycopy(seg[i], 0, pcm, i * 320, 320)
                        onSegment(pcm)
                    } else if (enrolling) {
                        vib(rejectBuzz)
                    }
                    inSpeech = false; hi = 0; lo = 0
                    seg.clear(); pre.clear()
                }
            }
        }
        rec.stop()
        rec.release()
    }

    private fun onSegment(pcm: ShortArray) {
        val f = Dsp.mfcc(pcm)
        if (f == null) {
            if (enrolling) vib(rejectBuzz)
            return
        }
        if (enrolling) {
            synchronized(samples) {
                samples.add(f)
                if (samples.size >= 5) finishEnroll() else vib(shortBuzz)
            }
        } else {
            detect(f)
        }
    }

    private fun nearestMean(f: Array<FloatArray>, others: List<Array<FloatArray>>): Float {
        val ds = others.map { Dsp.dtw(f, it) }.sorted()
        return ds.take(minOf(3, ds.size)).average().toFloat()
    }

    private fun detect(f: Array<FloatArray>) {
        val t = templates
        if (t.isEmpty()) return
        val lens = t.map { it.size }.sorted()
        val med = lens[lens.size / 2]
        if (f.size < med * 0.6 || f.size > med * 1.6) return
        if (nearestMean(f, t) <= thr) handler.post { speakTime() }
    }

    private fun finishEnroll() {
        val s = samples.toList()
        val inn = s.indices.map { i -> nearestMean(s[i], s.filterIndexed { j, _ -> j != i }) }
        val med = inn.sorted()[inn.size / 2]
        val keep = s.filterIndexed { i, _ -> inn[i] <= med * 2.0 }
        val use = if (keep.size >= 3) keep else s
        val threshold = (med * 1.7f).coerceIn(0.8f, 1.9f)
        templates = use
        thr = threshold
        saveTemplates(use, threshold)
        samples.clear()
        enrolling = false
        vib(doneBuzz)
    }

    override fun onStartCommand(i: Intent?, flags: Int, id: Int): Int {
        when (i?.action) {
            "SPEAK" -> speakTime()
            "ENROLL" -> {
                synchronized(samples) { samples.clear() }
                enrolling = true
                vib(shortBuzz)
            }
        }
        return START_STICKY
    }

    // ---------- speaking the time with the recorded clips ----------
    private fun res(name: String): Int = resources.getIdentifier(name, "raw", packageName)

    private fun speakTime() {
        if (speaking) return
        val c = Calendar.getInstance()
        val h24 = c.get(Calendar.HOUR_OF_DAY)
        var h = h24 % 12
        if (h == 0) h = 12
        val m = c.get(Calendar.MINUTE)
        val period = when {
            h24 in 4..11 -> "p_morning"
            h24 in 12..17 -> "p_afternoon"
            else -> "p_night"
        }
        val names = mutableListOf("intro", "h_$h")
        if (m > 0) names.add("m_$m")
        names.add(period)
        queue.clear()
        for (n in names) {
            val id = res(n)
            if (id != 0) queue.add(id)
        }
        speaking = true
        playNext()
    }

    private fun finishSpeaking() {
        player = null
        lastEnd = SystemClock.elapsedRealtime()
        speaking = false
    }

    private fun playNext() {
        if (queue.isEmpty()) { finishSpeaking(); return }
        val id = queue.removeAt(0)
        val mp = MediaPlayer.create(this, id)
        if (mp == null) { playNext(); return }
        player = mp
        mp.setWakeMode(this, PowerManager.PARTIAL_WAKE_LOCK)
        mp.setOnCompletionListener { it.release(); playNext() }
        mp.setOnErrorListener { p, _, _ -> p.release(); playNext(); true }
        mp.start()
    }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onDestroy() {
        running = false
        unregisterReceiver(receiver)
        player?.release()
        super.onDestroy()
    }
}
