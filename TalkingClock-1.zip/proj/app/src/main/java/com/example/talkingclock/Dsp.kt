package com.example.talkingclock

import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.ln
import kotlin.math.log10
import kotlin.math.max
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.sqrt

object Dsp {
    const val SR = 16000
    const val FR = 400
    const val HOP = 320
    const val NFFT = 512
    const val NMEL = 26
    const val NC = 12

    private val win = DoubleArray(FR) { 0.54 - 0.46 * cos(2.0 * PI * it / (FR - 1)) }
    private val fb: Array<DoubleArray> = buildFb()
    private val dct: Array<DoubleArray> =
        Array(NC) { i -> DoubleArray(NMEL) { j -> cos(PI * (i + 1) * (j + 0.5) / NMEL) } }

    private fun mel(f: Double) = 2595.0 * log10(1.0 + f / 700.0)
    private fun imel(m: Double) = 700.0 * (10.0.pow(m / 2595.0) - 1.0)

    private fun buildFb(): Array<DoubleArray> {
        val lo = mel(100.0)
        val hi = mel(6000.0)
        val bins = IntArray(NMEL + 2) {
            floor((NFFT + 1) * imel(lo + (hi - lo) * it / (NMEL + 1)) / SR).toInt()
        }
        val out = Array(NMEL) { DoubleArray(NFFT / 2 + 1) }
        for (m in 1..NMEL) {
            val l = bins[m - 1]
            val c = bins[m]
            val r = bins[m + 1]
            for (k in l until c) out[m - 1][k] = (k - l).toDouble() / max(c - l, 1)
            for (k in c until r) out[m - 1][k] = (r - k).toDouble() / max(r - c, 1)
        }
        return out
    }

    private fun fft(re: DoubleArray, im: DoubleArray) {
        val n = re.size
        var j = 0
        for (i in 1 until n) {
            var bit = n shr 1
            while ((j and bit) != 0) {
                j = j xor bit
                bit = bit shr 1
            }
            j = j xor bit
            if (i < j) {
                val tr = re[i]; re[i] = re[j]; re[j] = tr
                val ti = im[i]; im[i] = im[j]; im[j] = ti
            }
        }
        var len = 2
        while (len <= n) {
            val ang = -2.0 * PI / len
            val wr = cos(ang)
            val wi = sin(ang)
            var i = 0
            while (i < n) {
                var cr = 1.0
                var ci = 0.0
                for (k in 0 until len / 2) {
                    val a = i + k
                    val b = i + k + len / 2
                    val vr = re[b] * cr - im[b] * ci
                    val vi = re[b] * ci + im[b] * cr
                    re[b] = re[a] - vr
                    im[b] = im[a] - vi
                    re[a] = re[a] + vr
                    im[a] = im[a] + vi
                    val ncr = cr * wr - ci * wi
                    ci = cr * wi + ci * wr
                    cr = ncr
                }
                i += len
            }
            len = len shl 1
        }
    }

    /** Returns frames x NC features (normalized), or null if the audio is too short. */
    fun mfcc(pcm: ShortArray): Array<FloatArray>? {
        if (pcm.size < FR) return null
        val n = 1 + (pcm.size - FR) / HOP
        if (n < 12) return null
        val x = DoubleArray(pcm.size)
        x[0] = pcm[0].toDouble()
        for (i in 1 until pcm.size) x[i] = pcm[i].toDouble() - 0.97 * pcm[i - 1].toDouble()
        val out = Array(n) { FloatArray(NC) }
        val re = DoubleArray(NFFT)
        val im = DoubleArray(NFFT)
        val melE = DoubleArray(NMEL)
        for (f in 0 until n) {
            java.util.Arrays.fill(re, 0.0)
            java.util.Arrays.fill(im, 0.0)
            for (i in 0 until FR) re[i] = x[f * HOP + i] * win[i]
            fft(re, im)
            for (m in 0 until NMEL) {
                var s = 0.0
                val w = fb[m]
                for (k in 0..NFFT / 2) s += w[k] * (re[k] * re[k] + im[k] * im[k])
                melE[m] = ln(s + 1e-3)
            }
            for (c in 0 until NC) {
                var s = 0.0
                for (m in 0 until NMEL) s += dct[c][m] * melE[m]
                out[f][c] = s.toFloat()
            }
        }
        for (c in 0 until NC) {
            var mean = 0.0
            for (f in 0 until n) mean += out[f][c]
            mean /= n
            var v = 0.0
            for (f in 0 until n) {
                val dd = out[f][c] - mean
                v += dd * dd
            }
            val sd = sqrt(v / n) + 1e-6
            for (f in 0 until n) out[f][c] = ((out[f][c] - mean) / sd).toFloat()
        }
        return out
    }

    fun dtw(a: Array<FloatArray>, b: Array<FloatArray>): Float {
        val n = a.size
        val m = b.size
        var prev = FloatArray(m + 1) { 1e9f }
        prev[0] = 0f
        for (i in 1..n) {
            val cur = FloatArray(m + 1) { 1e9f }
            for (j in 1..m) {
                var s = 0f
                for (k in 0 until NC) {
                    val diff = a[i - 1][k] - b[j - 1][k]
                    s += diff * diff
                }
                cur[j] = sqrt(s) + minOf(prev[j - 1], prev[j], cur[j - 1])
            }
            prev = cur
        }
        return prev[m] / (n + m)
    }
}
