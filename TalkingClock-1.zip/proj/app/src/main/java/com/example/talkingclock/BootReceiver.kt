package com.example.talkingclock

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        // Android 11+ blocks microphone services started from boot: the user must open the app once.
        if (Build.VERSION.SDK_INT < 30) startTimeService(c, null)
    }
}
